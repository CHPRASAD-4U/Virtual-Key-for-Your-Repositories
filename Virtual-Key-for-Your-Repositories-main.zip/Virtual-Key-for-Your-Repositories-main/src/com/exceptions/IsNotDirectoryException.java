package com.exceptions;

public class IsNotDirectoryException extends Exception{

	public IsNotDirectoryException(String message) {
		super(message);
	}
	
}

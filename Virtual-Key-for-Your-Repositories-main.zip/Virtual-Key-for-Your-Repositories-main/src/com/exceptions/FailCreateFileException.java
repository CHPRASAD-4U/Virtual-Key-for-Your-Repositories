package com.exceptions;

public class FailCreateFileException extends Exception{

	public FailCreateFileException(String message) {
		super(message);
	}
	
}

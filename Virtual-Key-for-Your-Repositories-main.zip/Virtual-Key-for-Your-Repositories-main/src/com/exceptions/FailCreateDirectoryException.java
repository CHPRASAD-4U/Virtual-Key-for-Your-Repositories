package com.exceptions;

public class FailCreateDirectoryException extends Exception{

	public FailCreateDirectoryException(String message) {
		super(message);
	}
	
}

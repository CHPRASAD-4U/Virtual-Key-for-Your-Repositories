package com.exceptions;

public class NullDirectoryException extends Exception{

	public NullDirectoryException(String message) {
		super(message);
	}
	
}

package com.application.operations;

public interface ExitApplication {
	public void exitApp();
}
